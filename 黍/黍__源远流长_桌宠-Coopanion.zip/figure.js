const SVG_NS = 'http://www.w3.org/2000/svg';
const IDLE_BOX = [208, 351, 625, 807];
const SCALE = 240 / (IDLE_BOX[3] - IDLE_BOX[1]);
const X_OFFSET = 128 - ((IDLE_BOX[0] + IDLE_BOX[2]) / 2) * SCALE;
const SOURCE_SIZE = 1000;
const COMPANION_SECONDS = 6.33;

const CLIPS = {
  idle: { file: 'assets/idle.gif', seconds: 13.33, box: IDLE_BOX },
  walk: { file: 'assets/walk.gif', seconds: 3.67, box: [205, 345, 609, 792] },
  poke1: { file: 'assets/poke-1.gif', seconds: 5, box: [199, 350, 701, 792] },
  poke2: { file: 'assets/poke-2.gif', seconds: 27, box: [2, 401, 959, 798] },
  companion: { file: 'assets/companion.gif', seconds: COMPANION_SECONDS, box: [211, 453, 642, 876] },
  sleep: { file: 'assets/sleep.gif', seconds: 7.67, box: [276, 480, 840, 800] },
};

function randomIdleGap() {
  return 25 + Math.random() * 15;
}

function createFigure(asset) {
  const urls = Object.fromEntries(Object.entries(CLIPS).map(([id, clip]) => [id, String(asset(clip.file))]));
  let current = null;
  let sprite = null;
  let simulationTime = 0;
  let previousTime = null;
  let clickUntil = 0;
  let clickClip = 'poke2';
  let idleElapsed = 0;
  let nextIdleGap = randomIdleGap();
  let companionUntil = 0;

  function boundsFor(id) {
    const [x0, y0, x1, y1] = CLIPS[id].box;
    const yOffset = 256 - y1 * SCALE;
    return [
      Math.floor(X_OFFSET + x0 * SCALE) - 4,
      Math.floor(yOffset + y0 * SCALE) - 4,
      Math.ceil(X_OFFSET + x1 * SCALE) + 4,
      Math.ceil(yOffset + y1 * SCALE) + 4,
    ];
  }

  function choose(frame) {
    const now = Number.isFinite(frame.t) ? frame.t : simulationTime;
    const dt = previousTime === null ? 0 : Math.max(0, Math.min(0.25, now - previousTime));
    previousTime = now;
    simulationTime = now;

    if (clickUntil > now) return clickClip;
    if (frame.mode === 'walk' || frame.mode === 'run') {
      idleElapsed = 0;
      companionUntil = 0;
      return 'walk';
    }
    if (frame.mode === 'sleep') {
      idleElapsed = 0;
      companionUntil = 0;
      return 'sleep';
    }
    if (frame.gesture?.kind === 'companion') {
      idleElapsed = 0;
      companionUntil = 0;
      return 'companion';
    }
    if (frame.mode !== 'idle') {
      idleElapsed = 0;
      companionUntil = 0;
      return 'idle';
    }
    if (companionUntil > now) return 'companion';
    companionUntil = 0;

    idleElapsed += dt;
    if (idleElapsed >= nextIdleGap) {
      idleElapsed = 0;
      nextIdleGap = randomIdleGap();
      companionUntil = now + COMPANION_SECONDS;
      return 'companion';
    }
    return 'idle';
  }

  return {
    gestures: ['companion'],
    anchors: {
      gaze: [128, 104],
      tear: [128, 132],
      tears: [[116, 132], [140, 132]],
      z: [190, 36],
      hearts: [86, 84, 34],
      bubble: [128, 4],
    },
    hits: [[128, 128, 108]],
    get extent() {
      return boundsFor(current || 'idle');
    },
    draw(group, _face, frame) {
      const selected = choose(frame);
      if (!sprite) {
        sprite = group.ownerDocument.createElementNS(SVG_NS, 'image');
        sprite.setAttribute('preserveAspectRatio', 'none');
        sprite.style.pointerEvents = 'none';
        group.appendChild(sprite);
      }
      if (selected !== current) {
        current = selected;
        const clip = CLIPS[current];
        const yOffset = 256 - clip.box[3] * SCALE;
        sprite.setAttribute('href', urls[current]);
        sprite.setAttribute('x', String(X_OFFSET));
        sprite.setAttribute('y', String(yOffset));
        sprite.setAttribute('width', String(SOURCE_SIZE * SCALE));
        sprite.setAttribute('height', String(SOURCE_SIZE * SCALE));
      }
    },
    triggerPoke() {
      clickClip = Math.random() < 0.7 ? 'poke2' : 'poke1';
      clickUntil = simulationTime + CLIPS[clickClip].seconds;
    },
  };
}

export function createShuBody(_base, { kit, asset, host }) {
  const figure = createFigure(asset);
  const body = kit.createBody(host, {
    figure,
    words: {
      companion: { motion: { seconds: COMPANION_SECONDS } },
    },
  });
  let press = null;
  const now = (point) => point?.t ?? performance.now();
  const isHit = (point) => body.layout().hit.some((circle) => Math.hypot(point.x - circle.x, point.y - circle.y) < circle.r);

  return {
    step: (dt) => body.step(dt),
    layout: () => body.layout(),
    resize: () => body.resize?.(),
    do: (word) => body.do(word),
    walk: (x, run, id) => body.walk(x, run, id),
    stopWalk: (id) => body.stopWalk(id),
    pointer(type, point) {
      if (type === 'down') {
        const canPoke = isHit(point) && !['drag', 'air'].includes(body.layout().mode);
        const result = body.pointer(type, point);
        press = canPoke && result !== false ? { x: point.x, y: point.y, t: now(point), moved: false } : null;
        return result;
      }
      if (type === 'move' && press && Math.hypot(point.x - press.x, point.y - press.y) > 6) press.moved = true;
      if (type === 'up') {
        const down = press;
        const clicked = !!down && !down.moved && now(point) - down.t < 400 && Math.hypot(point.x - down.x, point.y - down.y) < 6;
        press = null;
        const result = body.pointer(type, point);
        if (clicked) figure.triggerPoke();
        return result;
      }
      if (type === 'cancel') press = null;
      return body.pointer(type, point);
    },
    drop: (point) => body.drop(point),
    shift: (dx, dy) => body.shift(dx, dy),
    place: (x, facing) => body.place(x, facing),
    set: (state) => body.set(state),
    cue: (kind) => body.cue(kind),
    talk: () => body.talk(),
    setScheme: (id, options) => body.setScheme(id, options),
    dispose: () => body.dispose(),
  };
}
