const SVG_NS = 'http://www.w3.org/2000/svg';
const SOURCE_SIZE = 1000;
const TRANSITION_SECONDS = 0.22;

const CLIPS = {
  sit: { file: 'assets/sit.gif', seconds: 1.13, box: [392, 518, 633, 807] },
  walk: { file: 'assets/walk.gif', seconds: 0.93, box: [362, 477, 614, 784] },
  sleep: { file: 'assets/sleep.gif', seconds: 1.33, box: [327, 568, 630, 797] },
  poke1: { file: 'assets/poke-1.gif', seconds: 12.17, box: [60, 495, 964, 797] },
  poke2: { file: 'assets/poke-2.gif', seconds: 5, box: [267, 488, 647, 821] },
};

const SIT_BOX = CLIPS.sit.box;
const SCALE = 240 / (SIT_BOX[3] - SIT_BOX[1]);

function boundsFor(id) {
  const [x0, y0, x1, y1] = CLIPS[id].box;
  const centerX = (x0 + x1) / 2;
  const imageX = 128 - centerX * SCALE;
  const imageY = 256 - y1 * SCALE;
  return [
    Math.floor(imageX + x0 * SCALE) - 4,
    Math.floor(imageY + y0 * SCALE) - 4,
    Math.ceil(imageX + x1 * SCALE) + 4,
    Math.ceil(imageY + y1 * SCALE) + 4,
  ];
}

function createFigure(asset) {
  const urls = Object.fromEntries(Object.entries(CLIPS).map(([id, clip]) => [id, String(asset(clip.file))]));
  const layers = [];
  let current = null;
  let currentToken = 0;
  let simulationTime = 0;
  let clickUntil = 0;
  let clickClip = 'poke2';
  let clickSerial = 0;

  function removeLayer(index) {
    const [layer] = layers.splice(index, 1);
    layer?.image.parentNode?.removeChild(layer.image);
  }

  function updateLayers(now) {
    for (let i = layers.length - 1; i >= 0; i--) {
      const layer = layers[i];
      const progress = Math.max(0, Math.min(1, (now - layer.started) / TRANSITION_SECONDS));
      const eased = progress * progress * (3 - 2 * progress);
      layer.opacity = layer.from + (layer.to - layer.from) * eased;
      layer.image.style.opacity = String(layer.opacity);
      if (progress >= 1) {
        layer.opacity = layer.to;
        if (layer.to === 0) removeLayer(i);
      }
    }
  }

  function addLayer(group, id, now, opacity, from, to) {
    const clip = CLIPS[id];
    const [x0, , x1, y1] = clip.box;
    const centerX = (x0 + x1) / 2;
    const image = group.ownerDocument.createElementNS(SVG_NS, 'image');
    image.setAttribute('preserveAspectRatio', 'none');
    image.setAttribute('href', urls[id]);
    image.setAttribute('x', String(128 - centerX * SCALE));
    image.setAttribute('y', String(256 - y1 * SCALE));
    image.setAttribute('width', String(SOURCE_SIZE * SCALE));
    image.setAttribute('height', String(SOURCE_SIZE * SCALE));
    image.style.pointerEvents = 'none';
    image.style.opacity = String(opacity);
    group.appendChild(image);
    layers.push({ id, image, opacity, from, to, started: now });
  }

  function select(group, id, now, token) {
    if (id === current && token === currentToken) return;

    updateLayers(now);
    for (let i = layers.length - 1; i >= 0; i--) {
      const layer = layers[i];
      if (layer.opacity <= 0.001) {
        removeLayer(i);
        continue;
      }
      layer.from = layer.opacity;
      layer.to = 0;
      layer.started = now;
    }

    const hasOutgoing = layers.length > 0;
    addLayer(group, id, now, hasOutgoing ? 0 : 1, hasOutgoing ? 0 : 1, 1);
    current = id;
    currentToken = token;
  }

  function choose(frame, now) {
    simulationTime = now;
    if (clickUntil > now) return clickClip;
    clickUntil = 0;

    if (frame.mode === 'walk' || frame.mode === 'run') return 'walk';
    if (frame.mode === 'sleep') return 'sleep';
    return 'sit';
  }

  return {
    anchors: {
      gaze: [128, 104],
      tear: [128, 132],
      tears: [[116, 132], [140, 132]],
      z: [190, 36],
      hearts: [86, 84, 34],
      bubble: [128, 4],
    },
    hits: [[128, 136, 96]],
    get extent() {
      const boxes = layers.filter((layer) => layer.opacity > 0.001).map((layer) => boundsFor(layer.id));
      if (!boxes.length) boxes.push(boundsFor(current || 'sit'));
      return [
        Math.min(...boxes.map((box) => box[0])),
        Math.min(...boxes.map((box) => box[1])),
        Math.max(...boxes.map((box) => box[2])),
        Math.max(...boxes.map((box) => box[3])),
      ];
    },
    draw(group, _face, frame) {
      const now = Number.isFinite(frame.t) ? frame.t : simulationTime;
      const selected = choose(frame, now);
      const token = selected === 'poke1' || selected === 'poke2' ? clickSerial : 0;
      select(group, selected, now, token);
      updateLayers(now);
    },
    triggerPoke() {
      clickClip = Math.random() < 0.7 ? 'poke2' : 'poke1';
      clickUntil = simulationTime + CLIPS[clickClip].seconds;
      clickSerial += 1;
    },
  };
}

export function createWeimeimeiBody(_base, { kit, asset, host }) {
  const figure = createFigure(asset);
  const body = kit.createBody(host, { figure });
  let press = null;
  const now = (point) => point?.t ?? performance.now();
  const isHit = (point) => body.layout().hit.some((circle) => Math.hypot(point.x - circle.x, point.y - circle.y) < circle.r);

  return {
    step: (dt) => body.step(dt),
    layout: () => body.layout(),
    resize: () => body.resize?.(),
    do: (word) => body.do(word),
    walk: (x, run, id) => body.walk(x, run, id),
    stopWalk: (id) => body.stopWalk(id),
    pointer(type, point) {
      if (type === 'down') {
        const canPoke = isHit(point) && !['drag', 'air'].includes(body.layout().mode);
        const result = body.pointer(type, point);
        press = canPoke && result !== false ? { x: point.x, y: point.y, t: now(point), moved: false } : null;
        return result;
      }
      if (type === 'move' && press && Math.hypot(point.x - press.x, point.y - press.y) > 6) press.moved = true;
      if (type === 'up') {
        const down = press;
        const clicked = !!down && !down.moved && now(point) - down.t < 400 && Math.hypot(point.x - down.x, point.y - down.y) < 6;
        press = null;
        const result = body.pointer(type, point);
        if (clicked) figure.triggerPoke();
        return result;
      }
      if (type === 'cancel') press = null;
      return body.pointer(type, point);
    },
    drop: (point) => body.drop(point),
    shift: (dx, dy) => body.shift(dx, dy),
    place: (x, facing) => body.place(x, facing),
    set: (state) => body.set(state),
    cue: (kind) => body.cue(kind),
    talk: () => body.talk(),
    setScheme: (id, options) => body.setScheme(id, options),
    dispose: () => body.dispose(),
  };
}
